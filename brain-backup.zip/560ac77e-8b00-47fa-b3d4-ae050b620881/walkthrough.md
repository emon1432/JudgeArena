# Codeforces User Rating History Walkthrough

## Incremental Sync & User Rating History Ingestion

### Architecture Highlights
- **User-Specific Scope**: Instead of global rating changes for 50+ million random users, JudgeArena ingests rating histories **strictly for registered platform users**, saving massive DB space and ensuring 100% relevant graph data.
- **Incremental Sync**: Uses `PlatformSyncEntityType::UserRatingHistory` to track user rating history sync state. Bulk sync skips previously synced users automatically.
- **On-Demand Single User Refresh**: Running `php artisan judgearena:import-user-rating-history codeforces <handle>` allows force-refreshing a specific user's rating history.
- **N+1 SQL Query Optimization**: Pre-indexes DB contests by `platform_contest_id` in memory to eliminate SQL query overhead inside rating loops.

---

## 🧪 Verification Results

1. **CLI Command Execution**:
   - `php artisan judgearena:import-user-rating-history codeforces` -> Executed successfully (`Exit Code: 0`).
   - `php artisan judgearena:import-user-rating-history codeforces tourist` -> Executed successfully (`Exit Code: 0`).

2. **Automated Feature Tests**:
   - Ran `php artisan test tests/Feature/ImportUserRatingHistoryTest.php`:
   ```
      PASS  Tests\Feature\ImportUserRatingHistoryTest
     ✓ user rating history import claims and syncs user rating changes

     Tests:    1 passed (10 assertions)
     Duration: 1.92s
   ```
