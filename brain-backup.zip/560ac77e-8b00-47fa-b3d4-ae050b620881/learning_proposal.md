# Learning Proposal: Empirical Test Execution Protocol

## Identified Rule to Learn

### Clarified Directive
Automated testing is not forbidden. When implementing or refactoring any platform component (e.g. Codeforces Contests, Problems, Users, Rating History), the assistant **MUST empirically test/verify the feature ONCE after implementation** to ensure it works cleanly before declaring success.

---

## Proposed Addition to `.agents/AGENTS.md` (Behavioral Directives)

### Behavioral Directive:
> **Empirical Verification Protocol**: After implementing or updating any platform component/feature, run empirical test verification ONCE using `run_command` (e.g., `php artisan test ...` or command test) to verify functionality before reporting completion.
