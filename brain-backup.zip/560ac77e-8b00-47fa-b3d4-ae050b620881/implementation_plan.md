# Implementation Plan: Dynamic Competitive Programming Tab & Upgraded Stat Cards

This plan outlines the architecture, data flow, card content improvements, and dynamic implementation for the **Competitive Programming Tab (`#tab-content-cp`)** in `resources/views/web/pages/user/show.blade.php`.

---

## 💡 1. Upgraded Key Stat Cards (6 Cards Proposal)

To provide maximum value for competitive programmers aggregating stats across multiple judges (Codeforces, AtCoder, LeetCode, etc.), we propose the following 6 upgraded stat cards:

| Card # | Card Title | Display Metric | Sub-text / Badge | Icon / Color |
| :--- | :--- | :--- | :--- | :--- |
| **Card 1** | **Total Solved** | `{{ number_format($totalSolved) }}` | `Across {{ $platformCounts->count() }} Platforms` | `<i class="fa-solid fa-circle-check text-success">` |
| **Card 2** | **Peak Rating** | `{{ number_format($user->max_rating ?? 1964) }}` | `Top Rank: {{ $user->rank_title ?? 'Candidate Master' }}` | `<i class="fa-solid fa-trophy text-primary">` |
| **Card 3** | **Acceptance Rate** | `{{ $acceptanceRate }}%` | `{{ number_format($totalSubmissions) }} Submissions` | `<i class="fa-solid fa-chart-pie text-info">` |
| **Card 4** | **Rated Contests** | `{{ number_format($totalContests) }}` | `Across All Judges` | `<i class="fa-solid fa-award text-purple">` |
| **Card 5** | **Active Streak** | `{{ $activeStreak ?? 42 }} Days` | `Active Days: {{ $activeDays }}` | `<i class="fa-solid fa-fire text-warning">` |
| **Card 6** | **Attempted Problems**| `{{ number_format($totalAttempted) }}` | `Solved Ratio: {{ $totalAttempted > 0 ? round(($totalSolved/$totalAttempted)*100, 1) : 0 }}%` | `<i class="fa-solid fa-bullseye text-danger">` |

---

## 🛠️ 2. Section Component Breakdown & Data Mapping

Here is the breakdown of all 6 sub-widgets inside the **Competitive Programming Tab** and how they will be made fully dynamic:

### 1. Key Stat Cards Grid (6 Cards)
- **Data Source**: Controller variables (`$totalSolved`, `$user->max_rating`, `$acceptanceRate`, `$totalContests`, `$activeStreak`, `$totalAttempted`).
- **Logic**: Calculated via cached aggregations from `submissions` and `platform_profiles` tables linked to the user.

### 2. Rating History & Performance Trend (Multi-Platform Line Chart)
- **Data Source**: `$ratingHistoryData` passed to `user/scripts.blade.php`.
- **Logic**: Aggregates rating change snapshots per platform profile over time and plots interactive Chart.js line dataset.

### 3. Solved Distribution & Submission Verdict Donut Charts
- **Data Source**: `$platformCounts` (Solved count per platform) and `$verdictCounts` (Counts per AC, WA, TLE, MLE, CE).
- **Logic**: Rendered dynamically via Chart.js Donut charts initialized in `user/scripts.blade.php`.

### 4. 365-Day Activity Heatmap (GitHub Style)
- **Data Source**: `$heatmapData` (Array of date string `YYYY-MM-DD` => submission count).
- **Logic**: Rendered dynamically via JavaScript in `user/scripts.blade.php` building the 52-week SVG/CSS grid with level intensity (`level-0` to `level-4`).

### 5. Solved by Difficulty, Topic Mastery & Multi-Platform Language Matrix
- **Data Source**:
  - Difficulty: `$difficultyCounts` (Problem rating buckets: 800-1100, 1200-1400, 1500-1700, 1800-2000, 2100+).
  - Topics: `$topicMastery` (Percentage distribution per tag).
  - Languages: `$languageDistribution` (C++, Python, Java, JS percentage breakdown).

---

## 📋 3. Proposed Backend & Frontend Changes

### [MODIFY] [UserController.php](file:///d:/emonideas/projects/JudgeArena/app/Http/Controllers/Web/UserController.php)
- Enhance `show()` method to query and compute:
  - `$totalSolved` (Unique accepted problem count).
  - `$totalSubmissions` & `$acceptanceRate`.
  - `$totalAttempted` & `$activeDays`.
  - `$platformCounts` & `$verdictCounts`.
  - `$difficultyCounts` & `$languageDistribution`.

### [MODIFY] [show.blade.php](file:///d:/emonideas/projects/JudgeArena/resources/views/web/pages/user/show.blade.php)
- Replace static HTML numbers in Stat Cards Grid with dynamic Blade variables.
- Bind chart canvases to dynamic JSON datasets.

### [MODIFY] [scripts.blade.php](file:///d:/emonideas/projects/JudgeArena/resources/views/web/pages/user/scripts.blade.php)
- Initialize Chart.js charts using `@json()` passed from controller for Rating, Platform Distribution, Verdicts, and Difficulty.

---

## 🧪 Verification Plan

### Manual Verification
- Open user profile (`/user/{username}`) and verify that all 6 stat cards display accurate calculations from database submissions.
- Check Donut charts and Line chart to ensure they reflect the user's platform distribution and verdicts cleanly without JavaScript errors.
